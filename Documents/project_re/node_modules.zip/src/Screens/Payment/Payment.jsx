import "./Payment.css"


const Payment = () => {
    return (
        <div>
            <h1>Payment Page</h1>
            <p>From here you will get an alert about your trip or hotel being booked successfully and will redirected to homepage</p>
        </div>
    )
}


export default Payment