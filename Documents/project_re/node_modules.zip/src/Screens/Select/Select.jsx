import "./Select.css"


const Select = () => {
    return (
        <div>
            <h1>Select Page</h1>
        </div>
    )
}


export default Select