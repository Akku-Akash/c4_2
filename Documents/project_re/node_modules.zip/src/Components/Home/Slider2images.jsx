export const Slider2images = [
    {
        "images": "https://www.tripodeal.com/img/coupon-flight-deal.png"
    },
    {
        "images": "https://www.tripodeal.com/img/call-flight-deal.png"
    },
    {
        "images": "https://www.tripodeal.com/img/madeinindia-flight-deal.png"
    },
    {
        "images": "https://www.tripodeal.com/img/guide-flight-deal.png"
    }
]