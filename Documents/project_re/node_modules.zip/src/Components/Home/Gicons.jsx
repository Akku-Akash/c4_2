
// import { Giconimages } from "./Giconimages";

export const Gicons = () => {
    return (
        <div id="cont">
            <div id="icon">
                <img src="https://www.tripodeal.com/img/footer-trustlogo_new.png?ddf" alt="" />
            </div>
        </div>
    )
}