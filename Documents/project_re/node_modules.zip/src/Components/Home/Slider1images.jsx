export const Slider1images = [
    {
        "images": "https://www.tripodeal.com/img/slide-52.png"
    },
    {
        "images": "https://www.tripodeal.com/img/slide-51.jpg"
    },
    {
        "images": "https://www.tripodeal.com/img/slide-13.jpg"
    },
    {
        "images": "https://www.tripodeal.com/img/slide-8.jpg"
    }
]