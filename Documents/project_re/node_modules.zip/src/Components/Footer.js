import React from "react"



const Footer =() => {
    return (
        <div>
            <h3>Footer section</h3>
        </div>
    )
}

export default Footer